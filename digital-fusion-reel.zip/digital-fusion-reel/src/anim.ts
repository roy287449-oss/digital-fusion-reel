import {Easing, interpolate} from 'remotion';

export const OUT = Easing.bezier(0.16, 1, 0.3, 1);
export const INOUT = Easing.bezier(0.65, 0, 0.35, 1);

/** 0→1 progress starting at `start`, lasting `dur` frames. */
export const p = (frame: number, start: number, dur: number, easing = OUT) =>
  interpolate(frame, [start, start + dur], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });

export const clamp01 = (n: number) => Math.min(1, Math.max(0, n));

/** Gentle floating drift for parallax. */
export const drift = (frame: number, speed: number, amp: number, phase = 0) =>
  Math.sin(frame * speed + phase) * amp;
