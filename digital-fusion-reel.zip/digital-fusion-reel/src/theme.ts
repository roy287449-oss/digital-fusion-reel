import {loadFont as loadInter} from '@remotion/google-fonts/Inter';
import {loadFont as loadMono} from '@remotion/google-fonts/JetBrainsMono';

const inter = loadInter('normal', {weights: ['400', '500', '700', '900'], subsets: ['latin']});
const mono = loadMono('normal', {weights: ['400', '500'], subsets: ['latin']});

export const SANS = `${inter.fontFamily}, "Helvetica Neue", Arial, sans-serif`;
export const MONO = `${mono.fontFamily}, "SF Mono", Menlo, monospace`;

export const C = {
  black: '#0A0A0A',
  off: '#ECE9E3',
  red: '#E10600',
  char: '#1B1B1B',
  grey: '#8A8782',
};

export const W = 720;
export const H = 1280;
export const FPS = 30;

// Scene lengths in frames @30fps: 4s, 6s, 7s, 7s, 7s, 5s, 5s = 41s
export const SCENE_FRAMES = [120, 180, 210, 210, 210, 150, 150];
export const TOTAL_FRAMES = SCENE_FRAMES.reduce((a, b) => a + b, 0); // 1230
