import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BRAND} from '../config';
import {C, MONO, SANS} from '../theme';
import {p} from '../anim';
import {Checker, Label, MaskLine, TopBar} from '../ui';

// Scene 6 (31–36s): call to action, oversized type, red accent circle.
export const Scene6: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const circle = spring({frame: f - 4, fps, config: {damping: 20, stiffness: 70}});
  const btn = spring({frame: f - 60, fps, config: {damping: 12, stiffness: 110}});
  const cx = 360;
  const cy = 960;

  return (
    <AbsoluteFill style={{background: C.off}}>
      <TopBar left="Final · DF-06" right="" start={4} />
      <div style={{position: 'absolute', right: 48, top: 50, opacity: p(f, 6, 14)}}>
        <Checker size={28} />
      </div>

      <div
        style={{
          position: 'absolute',
          left: cx - 350,
          top: cy - 350,
          width: 700,
          height: 700,
          borderRadius: '50%',
          background: C.red,
          transform: `scale(${circle})`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: cx - 350,
          top: cy - 350,
          width: 700,
          height: 700,
          borderRadius: '50%',
          boxShadow: 'inset 0 -40px 80px rgba(0,0,0,0.28)',
          transform: `scale(${circle})`,
        }}
      />

      <div style={{position: 'absolute', left: 48, right: 48, top: 150}}>
        <MaskLine text="LET'S" size={150} start={8} />
        <MaskLine text="BUILD" size={150} start={14} />
        <MaskLine text={<span style={{color: C.red}}>YOURS.</span>} size={150} start={20} />
      </div>

      {/* rotating text badge */}
      <svg
        width={240}
        height={240}
        viewBox="0 0 240 240"
        style={{position: 'absolute', left: cx - 120, top: 790, transform: `rotate(${f * 2}deg)`, opacity: p(f, 36, 16)}}
      >
        <defs>
          <path id="circ" d="M120,120 m-92,0 a92,92 0 1,1 184,0 a92,92 0 1,1 -184,0" />
        </defs>
        <text fontFamily={MONO} fontSize="15" fill="#fff" textLength="570" lengthAdjust="spacing">
          <textPath href="#circ">DIGITAL FUSION • START A PROJECT • NOW •</textPath>
        </text>
      </svg>
      <div style={{position: 'absolute', left: cx - 40, top: 910 - 40, width: 80, height: 80, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: SANS, fontWeight: 900, fontSize: 70, color: '#fff', opacity: p(f, 40, 16)}}>
        ↗
      </div>

      <div
        style={{
          position: 'absolute',
          left: cx - 220,
          top: 1070,
          width: 440,
          height: 84,
          borderRadius: 42,
          background: C.black,
          color: '#fff',
          fontFamily: SANS,
          fontWeight: 700,
          fontSize: 32,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 14,
          transform: `scale(${btn})`,
        }}
      >
        Start a project <span style={{color: C.red}}>→</span>
      </div>

      <Label color="#fff" start={80} style={{position: 'absolute', left: 0, right: 0, textAlign: 'center', bottom: 64}}>
        {BRAND.phone}
      </Label>
    </AbsoluteFill>
  );
};
