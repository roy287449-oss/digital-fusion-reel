import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BRAND} from '../config';
import {C} from '../theme';
import {p} from '../anim';
import {Barcode, Label, MaskLine, Ring, TopBar} from '../ui';

// Scene 1 (0–4s): off-white, tiny labels, small geometric element, name reveal.
export const Scene1: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame: f - 6, fps, config: {damping: 14, stiffness: 120}});
  const ringT = p(f, 0, 40);
  const cx = 360;
  const cy = 400;
  const ang = (f / 120) * Math.PI * 1.5 - Math.PI / 2;

  return (
    <AbsoluteFill style={{background: C.off}}>
      <TopBar left={BRAND.name} mid="Presents" right="(01)" />

      <div style={{position: 'absolute', left: 48, right: 48, top: cy, height: 1, background: C.black, opacity: 0.14, transform: `scaleX(${ringT})`}} />
      <Ring cx={cx} cy={cy} size={380} scale={ringT} opacity={0.3} />
      <Ring cx={cx} cy={cy} size={290} dashed color={C.red} opacity={0.85} rot={f * 1.2} scale={ringT} />
      <div style={{position: 'absolute', left: cx - 32, top: cy - 32, width: 64, height: 64, borderRadius: '50%', background: C.red, transform: `scale(${pop})`}} />
      <div
        style={{
          position: 'absolute',
          left: cx + Math.cos(ang) * 190 - 7,
          top: cy + Math.sin(ang) * 190 - 7,
          width: 14,
          height: 14,
          background: C.black,
          opacity: ringT,
        }}
      />

      <div style={{position: 'absolute', left: 48, right: 48, top: 640}}>
        <MaskLine text={BRAND.nameTop} start={28} size={132} />
        <MaskLine
          text={
            <>
              {BRAND.nameBottom}
              <span style={{color: C.red}}>.</span>
            </>
          }
          start={38}
          size={132}
        />
      </div>

      <Label start={64} style={{position: 'absolute', left: 48, top: 960}}>
        {BRAND.tagline}
      </Label>

      <div style={{position: 'absolute', left: 48, bottom: 64, opacity: p(f, 50, 20)}}>
        <Barcode w={150} h={34} seed="s1" />
      </div>
      <Label start={56} style={{position: 'absolute', right: 48, bottom: 64}}>
        DF — {BRAND.year}
      </Label>
    </AbsoluteFill>
  );
};
