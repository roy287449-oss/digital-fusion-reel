import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C} from '../theme';
import {INOUT, drift, p} from '../anim';
import {Barcode, BlurText, Label, MaskLine, Ring, TopBar} from '../ui';
import {AppScreen, Chip, Phone, Website} from '../objects';

// Scene 4 (17–24s): modern websites + custom apps, mockups, UI chips, parallax.
export const Scene4: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cam = interpolate(f, [0, 210], [1, 1.07], {easing: INOUT});
  const webT = p(f, 14, 70);
  const phoneT = p(f, 50, 70);
  const phoneIn = spring({frame: f - 36, fps, config: {damping: 16, stiffness: 80}});
  const chip = (start: number) => spring({frame: f - start, fps, config: {damping: 12, stiffness: 120}});

  return (
    <AbsoluteFill style={{background: C.off}}>
      <TopBar left="Exhibit 04" mid="Web + Apps" right="(04)" start={8} />

      <div style={{position: 'absolute', left: 48, right: 48, top: 130}}>
        <BlurText text="Websites & custom apps" size={30} start={8} />
        <MaskLine text="Own your" size={78} start={14} />
        <MaskLine text={<>digital home<span style={{color: C.red}}>.</span></>} size={78} start={22} />
      </div>

      <div style={{position: 'absolute', inset: 0, transform: `scale(${cam})`, transformOrigin: '50% 60%'}}>
        <div
          style={{
            position: 'absolute',
            left: 90,
            top: 520,
            width: 330,
            height: 330,
            borderRadius: '50%',
            background: C.red,
            transform: `scale(${p(f, 10, 40)})`,
          }}
        />
        <Ring cx={300} cy={685} size={460} dashed color={C.red} opacity={0.6} rot={f * 0.6} />

        {/* website, tilted for depth */}
        <div
          style={{
            position: 'absolute',
            left: 48,
            top: 470 + drift(f, 0.04, 8),
            perspective: 1600,
            opacity: p(f, 10, 20),
          }}
        >
          <div style={{transform: `rotateY(${-9 + drift(f, 0.03, 2)}deg) rotateX(4deg) scale(0.9)`, transformOrigin: '0 0'}}>
            <Website t={webT} />
          </div>
        </div>

        {/* phone, overlapping, faster parallax */}
        <div
          style={{
            position: 'absolute',
            left: 430,
            top: 640 + drift(f, 0.05, 12, 1) + (1 - phoneIn) * 300,
            transform: 'scale(0.78)',
            transformOrigin: '0 0',
          }}
        >
          <Phone>
            <AppScreen t={phoneT} />
          </Phone>
        </div>

        <Chip style={{position: 'absolute', left: 60, top: 920 + drift(f, 0.06, 6), transform: `scale(${chip(78)})`, transformOrigin: '0 50%'}}>
          Customer data
        </Chip>
        <Chip dark style={{position: 'absolute', left: 250, top: 1000 + drift(f, 0.05, 6, 2), transform: `scale(${chip(96)})`, transformOrigin: '0 50%'}}>
          3:00 AM · New order
        </Chip>
        <Chip style={{position: 'absolute', left: 60, top: 1080 + drift(f, 0.05, 6, 4), transform: `scale(${chip(114)})`, transformOrigin: '0 50%'}}>
          Your brand
        </Chip>
      </div>

      <div style={{position: 'absolute', left: 48, bottom: 64, opacity: p(f, 90, 20)}}>
        <Barcode w={120} h={26} seed="s4" />
      </div>
      <Label start={100} style={{position: 'absolute', right: 48, bottom: 64}}>Always open</Label>
    </AbsoluteFill>
  );
};
