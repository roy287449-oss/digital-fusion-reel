import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, MONO, SANS} from '../theme';
import {INOUT, drift, p} from '../anim';
import {Beat, BlurText, Label, MaskLine, Ring, TopBar} from '../ui';
import {AppScreen, Phone, Tile, Website} from '../objects';

const STEP = 52; // frames per service
const OFFSET = 4;

const SERVICES = [
  {tag: 'WEB', a: 'Website', b: 'design.', sub: 'Fast, considered, built to convert.'},
  {tag: 'APP', a: 'Custom', b: 'applications.', sub: 'Tools shaped around how you work.'},
  {tag: 'AUTO', a: 'Business', b: 'automation.', sub: 'Repetitive work, handled for you.'},
  {tag: 'BRAND', a: 'Digital', b: 'branding.', sub: 'One identity, everywhere you show up.'},
];

const Frame: React.FC<{idx: number; children: React.ReactNode}> = ({idx, children}) => {
  const s = SERVICES[idx];
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 48, right: 48, top: 130}}>
        <Label color={C.red} size={16}>0{idx + 1} / 04 — {s.tag}</Label>
        <div style={{height: 14}} />
        <MaskLine text={s.a} size={80} color={C.off} start={0} />
        <MaskLine text={<>{s.b}</>} size={80} color={C.off} start={5} />
        <BlurText text={s.sub} size={26} color="#9a9792" start={12} weight={400} style={{marginTop: 10}} />
      </div>
      {children}
    </AbsoluteFill>
  );
};

const WebVisual: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', left: 80, top: 560 + drift(f, 0.06, 6), perspective: 1600}}>
      <div style={{transform: 'rotateY(-10deg) rotateX(5deg)'}}>
        <Website t={p(f, 4, 30)} />
      </div>
    </div>
  );
};

const AppVisual: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <>
      <div style={{position: 'absolute', left: 210, top: 560 + drift(f, 0.06, 6), transform: 'scale(1.0)', transformOrigin: '0 0'}}>
        <Phone>
          <AppScreen t={p(f, 4, 32)} />
        </Phone>
      </div>
      <Tile size={96} red style={{position: 'absolute', left: 70, top: 640 + drift(f, 0.07, 8, 1), opacity: p(f, 12, 14)}}>D</Tile>
      <Tile size={72} style={{position: 'absolute', left: 90, top: 790 + drift(f, 0.07, 8, 3), opacity: p(f, 18, 14)}}>↗</Tile>
    </>
  );
};

const AutoVisual: React.FC = () => {
  const f = useCurrentFrame();
  const travel = p(f, 6, 40, INOUT);
  const dotY = 100 + travel * 340;
  const nodes = [
    {y: 20, label: 'New order'},
    {y: 230, label: 'Invoice sent'},
    {y: 440, label: 'Customer notified'},
  ];
  return (
    <div style={{position: 'absolute', left: 48, top: 560, width: 624, height: 540}}>
      <svg width={624} height={540} viewBox="0 0 624 540" style={{position: 'absolute', inset: 0}}>
        <line x1={312} x2={312} y1={100} y2={230} stroke={C.off} strokeOpacity={0.3} strokeDasharray="4 6" />
        <line x1={312} x2={312} y1={310} y2={440} stroke={C.off} strokeOpacity={0.3} strokeDasharray="4 6" />
        <line x1={312} x2={312} y1={100} y2={Math.min(dotY, 440)} stroke={C.red} strokeWidth={3} />
        <circle cx={312} cy={dotY} r={10} fill={C.red} />
      </svg>
      {nodes.map((n, i) => {
        const lit = dotY >= n.y + 70;
        return (
          <div
            key={n.label}
            style={{
              position: 'absolute',
              left: 187,
              top: n.y,
              width: 250,
              height: 80,
              borderRadius: 16,
              background: C.char,
              border: `2px solid ${lit || i === 0 ? C.red : 'rgba(236,233,227,0.25)'}`,
              color: C.off,
              fontFamily: SANS,
              fontWeight: 700,
              fontSize: 24,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              opacity: p(f, i * 6, 12),
            }}
          >
            {n.label}
          </div>
        );
      })}
      <Label color={C.off} start={20} style={{position: 'absolute', left: 0, top: 250}}>Auto</Label>
      <Label color={C.off} start={24} style={{position: 'absolute', right: 0, top: 250}}>No manual steps</Label>
    </div>
  );
};

const BrandVisual: React.FC = () => {
  const f = useCurrentFrame();
  const t = p(f, 2, 26);
  const swatches = [C.black, C.off, C.red, C.char];
  return (
    <>
      <Ring cx={360} cy={760} size={470} opacity={0.3} color={C.off} scale={t} />
      <Ring cx={360} cy={760} size={400} dashed color={C.red} opacity={0.8} rot={f * 1.5} scale={t} />
      <div
        style={{
          position: 'absolute',
          left: 360 - 150,
          top: 760 - 150,
          width: 300,
          height: 300,
          borderRadius: '50%',
          background: C.red,
          transform: `scale(${t})`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: SANS,
          fontWeight: 900,
          fontSize: 150,
          letterSpacing: '-0.06em',
          color: '#fff',
        }}
      >
        Aa
      </div>
      <div style={{position: 'absolute', left: 48, right: 48, top: 1040, display: 'flex', gap: 14, justifyContent: 'center'}}>
        {swatches.map((c, i) => (
          <div key={c} style={{opacity: p(f, 14 + i * 4, 12), transform: `translateY(${(1 - p(f, 14 + i * 4, 12)) * 20}px)`}}>
            <div style={{width: 90, height: 60, borderRadius: 10, background: c, border: '1px solid rgba(236,233,227,0.3)'}} />
            <div style={{fontFamily: MONO, fontSize: 12, color: C.off, opacity: 0.7, marginTop: 8, textAlign: 'center'}}>{c.toUpperCase()}</div>
          </div>
        ))}
      </div>
    </>
  );
};

// Scene 5 (24–31s): four services, one per beat, charcoal stage.
export const Scene5: React.FC = () => {
  const f = useCurrentFrame();
  const active = Math.min(3, Math.max(0, Math.floor((f - OFFSET) / STEP)));
  const visuals = [<WebVisual key="w" />, <AppVisual key="a" />, <AutoVisual key="u" />, <BrandVisual key="b" />];

  return (
    <AbsoluteFill style={{background: C.char}}>
      <TopBar left="Our services" right="(05)" color={C.off} start={4} />
      {SERVICES.map((_, i) => (
        <Beat key={i} from={OFFSET + i * STEP} dur={i === 3 ? 210 - (OFFSET + 3 * STEP) : STEP} exit={i === 3 ? 1 : 8}>
          <Frame idx={i}>{visuals[i]}</Frame>
        </Beat>
      ))}

      {/* progress rail */}
      <div style={{position: 'absolute', left: 48, right: 48, bottom: 64, display: 'flex', gap: 10}}>
        {SERVICES.map((s, i) => {
          const fill = i < active ? 1 : i === active ? p(f, OFFSET + i * STEP, STEP, (x) => x) : 0;
          return (
            <div key={s.tag} style={{flex: 1}}>
              <div style={{height: 3, background: 'rgba(236,233,227,0.2)', position: 'relative'}}>
                <div style={{position: 'absolute', inset: 0, width: `${fill * 100}%`, background: C.red}} />
              </div>
              <div style={{fontFamily: MONO, fontSize: 12, letterSpacing: '0.12em', color: C.off, opacity: i === active ? 0.9 : 0.4, marginTop: 8}}>
                {s.tag}
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
