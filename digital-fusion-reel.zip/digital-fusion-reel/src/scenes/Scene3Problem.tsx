import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, MONO} from '../theme';
import {drift, p} from '../anim';
import {Beat, BlurText, Label, MaskLine, TopBar} from '../ui';
import {Sphere} from '../objects';

// Scene 3 (10–17s): black, the problem: growth on rented platforms.
export const Scene3: React.FC = () => {
  const f = useCurrentFrame();
  const sphereY = drift(f, 0.035, 14);
  const rise = p(f, 20, 60);
  const crash = p(f, 88, 22);

  return (
    <AbsoluteFill style={{background: C.black}}>
      <TopBar left="Note 03" right="* Platform risk" color={C.off} start={8} />

      {/* glossy sphere, partly off-canvas, drifting */}
      <div style={{position: 'absolute', left: -170, top: 700 + sphereY, opacity: p(f, 0, 30)}}>
        <Sphere size={460} style={{boxShadow: 'none'}} />
      </div>
      <div style={{position: 'absolute', right: 70, top: 470 - sphereY, opacity: p(f, 10, 30)}}>
        <Sphere size={54} red />
      </div>

      <Beat from={8} dur={74}>
        <div style={{position: 'absolute', left: 48, right: 48, top: 230}}>
          <BlurText text="Your followers" size={36} color="#9a9792" />
          <MaskLine text="aren't" size={150} color={C.off} start={6} />
          <MaskLine text="yours." size={150} color={C.off} start={12} />
        </div>
      </Beat>

      <Beat from={84} dur={70}>
        <div style={{position: 'absolute', left: 48, right: 48, top: 230}}>
          <BlurText text="One algorithm update," size={36} color="#9a9792" />
          <MaskLine text="reach" size={150} color={C.off} start={4} />
          <MaskLine text={<>drops<span style={{color: C.red}}>.</span></>} size={150} color={C.off} start={10} />
        </div>
      </Beat>

      <Beat from={156} dur={54} exit={1}>
        <div style={{position: 'absolute', left: 48, right: 48, top: 200}}>
          <BlurText text="You're building on" size={36} color="#9a9792" />
          <MaskLine text="RENTED" size={150} color={C.red} start={4} />
          <MaskLine text="LAND." size={150} color={C.off} start={10} />
        </div>
      </Beat>

      {/* falling reach graph (illustrative, no data) */}
      <div style={{position: 'absolute', left: 48, top: 800, width: 624, height: 280}}>
        <Label color={C.off} start={14} style={{position: 'absolute', left: 0, top: 0}}>Reach</Label>
        <Label color={C.red} start={88} style={{position: 'absolute', left: 392, top: 0}}>Algorithm update</Label>
        <svg width={624} height={280} viewBox="0 0 624 280" style={{position: 'absolute', inset: 0, overflow: 'visible'}}>
          {[60, 120, 180, 240].map((y) => (
            <line key={y} x1={0} x2={624} y1={y} y2={y} stroke={C.off} strokeOpacity={0.1} />
          ))}
          <path d="M0 200 L90 170 L180 150 L270 110 L360 90 L440 70" fill="none" stroke={C.off} strokeWidth={4} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - rise} />
          <path d="M440 70 L470 240 L540 250 L624 258" fill="none" stroke={C.red} strokeWidth={5} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - crash} />
          <line x1={440} x2={440} y1={70} y2={280} stroke={C.red} strokeOpacity={0.5} strokeDasharray="4 6" opacity={p(f, 86, 8)} />
          <circle cx={440} cy={70} r={9} fill={C.red} opacity={p(f, 80, 8)} />
        </svg>
      </div>

      <div style={{position: 'absolute', left: 48, bottom: 64, fontFamily: MONO, fontSize: 14, letterSpacing: '0.12em', color: C.off, opacity: 0.5 * p(f, 30, 20)}}>
        ILLUSTRATIVE
      </div>
    </AbsoluteFill>
  );
};
