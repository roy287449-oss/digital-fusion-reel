import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BRAND} from '../config';
import {C} from '../theme';
import {INOUT, drift, p} from '../anim';
import {Barcode, BlurText, Label, MaskLine, Ring, TopBar} from '../ui';
import {Cube, Sphere} from '../objects';

// Scene 2 (4–10s): red/black 3D cube with camera-like push, scale and precise type.
export const Scene2: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cx = 360;
  const cy = 500;

  const pop = spring({frame: f - 10, fps, config: {damping: 18, stiffness: 90}});
  const ry = interpolate(f, [0, 180], [-35, 215], {easing: INOUT});
  const rx = -22 + Math.sin(f / 28) * 6;
  const cam = interpolate(f, [0, 180], [1, 1.14], {easing: INOUT}); // camera push
  const px = drift(f, 0.03, 10);
  const circleT = p(f, 4, 36);
  const orbit = (f / 180) * Math.PI * 2;

  return (
    <AbsoluteFill style={{background: C.off}}>
      <TopBar left="Fig. 02" mid={BRAND.name} right="Ref · DF-01" start={6} />

      <div
        style={{
          position: 'absolute',
          left: cx - 260,
          top: cy - 260,
          width: 520,
          height: 520,
          borderRadius: '50%',
          background: C.red,
          transform: `scale(${circleT * cam})`,
        }}
      />
      <Ring cx={cx} cy={cy} size={650} opacity={0.3} scale={circleT} />
      <Ring cx={cx} cy={cy} size={560} dashed color={C.red} opacity={0.7} rot={-f * 0.8} scale={circleT} />

      {/* soft floor shadow */}
      <div style={{position: 'absolute', left: cx - 130, top: cy + 190, width: 260, height: 34, borderRadius: '50%', background: 'rgba(0,0,0,0.35)', filter: 'blur(18px)', opacity: pop}} />

      <div
        style={{
          position: 'absolute',
          left: cx - 115 + px,
          top: cy - 115,
          perspective: 1400,
          transform: `scale(${pop * cam})`,
        }}
      >
        <Cube s={230} rx={rx} ry={ry} />
      </div>

      <div style={{position: 'absolute', left: cx + Math.cos(orbit) * 310 - 30, top: cy + Math.sin(orbit) * 120 - 30 + 40, opacity: pop}}>
        <Sphere size={60} red />
      </div>
      <div style={{position: 'absolute', left: cx + Math.cos(orbit + Math.PI) * 300 - 18, top: cy + Math.sin(orbit + Math.PI) * 110 - 18 + 40, opacity: pop}}>
        <Sphere size={36} />
      </div>

      <Label start={30} style={{position: 'absolute', left: 48, top: 760}}>W 230 · D 230 · H 230</Label>
      <Label start={36} style={{position: 'absolute', right: 48, top: 760}}>Rot Y {Math.round(ry)}°</Label>

      <div style={{position: 'absolute', left: 48, right: 48, top: 850}}>
        <BlurText text="We build digital" start={40} size={34} weight={500} />
        <MaskLine text={<>ASSETS<span style={{color: C.red}}>.</span></>} start={50} size={150} />
        <BlurText text="you actually own." start={66} size={38} weight={700} style={{marginTop: 6}} />
      </div>

      <div style={{position: 'absolute', left: 48, bottom: 64, opacity: p(f, 70, 20)}}>
        <Barcode w={150} h={30} seed="s2" />
      </div>
    </AbsoluteFill>
  );
};
