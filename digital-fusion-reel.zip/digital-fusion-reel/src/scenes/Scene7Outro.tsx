import React from 'react';
import {AbsoluteFill, Img, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {BRAND} from '../config';
import {C, MONO, SANS} from '../theme';
import {p} from '../anim';
import {BlurText, Label, Ring, TopBar} from '../ui';

// Scene 7 (36–41s): black, logo placeholder reveal, contact details, clean end frame.
export const Scene7: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame: f - 6, fps, config: {damping: 16, stiffness: 90}});
  const cx = 360;
  const cy = 360;

  return (
    <AbsoluteFill style={{background: C.black}}>
      <TopBar left={BRAND.name} right={`© ${BRAND.year}`} color={C.off} start={4} />

      <Ring cx={cx} cy={cy} size={420} color={C.off} opacity={0.22} scale={p(f, 0, 40)} />
      <Ring cx={cx} cy={cy} size={330} color={C.red} dashed opacity={0.8} rot={f * 0.8} scale={p(f, 4, 40)} />

      {/* LOGO PLACEHOLDER: set BRAND.logoSrc in src/config.ts to use your real logo */}
      <div
        style={{
          position: 'absolute',
          left: cx - 90,
          top: cy - 90,
          width: 180,
          height: 180,
          transform: `scale(${pop})`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {BRAND.logoSrc ? (
          <Img src={staticFile(BRAND.logoSrc)} style={{width: 180, height: 180, objectFit: 'contain'}} />
        ) : (
          <div
            style={{
              width: 180,
              height: 180,
              borderRadius: '50%',
              border: `2px dashed ${C.off}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: MONO,
              fontSize: 16,
              letterSpacing: '0.2em',
              color: C.off,
              opacity: 0.8,
            }}
          >
            [ LOGO ]
          </div>
        )}
      </div>

      <div style={{position: 'absolute', left: 48, right: 48, top: 640, textAlign: 'center'}}>
        <BlurText text={BRAND.name.toUpperCase()} by="char" start={26} stagger={2} size={58} weight={900} color={C.off} align="center" ls="0.04em" />
        <Label color={C.red} start={56} style={{marginTop: 18, textAlign: 'center'}}>{BRAND.tagline}</Label>
      </div>

      <div style={{position: 'absolute', left: 48, right: 48, top: 900, height: 1, background: C.off, opacity: 0.2, transform: `scaleX(${p(f, 50, 30)})`}} />

      <div style={{position: 'absolute', left: 48, right: 48, top: 940, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18}}>
        {[BRAND.phone, BRAND.email, BRAND.website].map((line, i) => (
          <div
            key={line}
            style={{
              fontFamily: SANS,
              fontWeight: i === 0 ? 700 : 400,
              fontSize: i === 0 ? 44 : 30,
              color: C.off,
              opacity: p(f, 60 + i * 8, 16) * (i === 0 ? 1 : 0.75),
              transform: `translateY(${(1 - p(f, 60 + i * 8, 16)) * 16}px)`,
              letterSpacing: '-0.01em',
            }}
          >
            {line}
          </div>
        ))}
      </div>

      <Label color={C.off} start={90} style={{position: 'absolute', left: 0, right: 0, bottom: 64, textAlign: 'center'}}>
        Digital Fusion · {BRAND.year}
      </Label>
    </AbsoluteFill>
  );
};
