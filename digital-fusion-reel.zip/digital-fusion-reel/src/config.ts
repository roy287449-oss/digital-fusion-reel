// ─────────────────────────────────────────────────────────────
//  EDIT THIS FILE: all brand details live here.
//  Nothing below is real contact data. Replace the placeholders.
// ─────────────────────────────────────────────────────────────
export const BRAND = {
  name: 'Digital Fusion',
  nameTop: 'DIGITAL',
  nameBottom: 'FUSION',
  tagline: 'Websites · Apps · Automation · Branding',
  // Put your logo in /public (e.g. public/logo.png) and set: logoSrc: 'logo.png'
  // While null, a dashed "LOGO" placeholder is shown instead.
  logoSrc: null as string | null,
  phone: '+00 00000 00000', // PLACEHOLDER: replace with your number
  email: 'hello@yourdomain.com', // PLACEHOLDER
  website: 'yourdomain.com', // PLACEHOLDER
  year: '2026',
};
