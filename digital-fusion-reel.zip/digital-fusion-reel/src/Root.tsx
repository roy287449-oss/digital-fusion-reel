import React from 'react';
import {Composition} from 'remotion';
import {MainVideo} from './MainVideo';
import {FPS, H, TOTAL_FRAMES, W} from './theme';

export const RemotionRoot: React.FC = () => (
  <Composition id="DigitalFusionReel" component={MainVideo} durationInFrames={TOTAL_FRAMES} fps={FPS} width={W} height={H} />
);
