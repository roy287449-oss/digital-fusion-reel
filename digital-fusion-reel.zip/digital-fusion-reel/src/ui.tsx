import React from 'react';
import {AbsoluteFill, interpolate, random, Sequence, useCurrentFrame} from 'remotion';
import {C, MONO, SANS} from './theme';
import {INOUT, p} from './anim';

/** Tiny uppercase technical label. */
export const Label: React.FC<{
  children: React.ReactNode;
  start?: number;
  color?: string;
  size?: number;
  style?: React.CSSProperties;
}> = ({children, start = 0, color = C.black, size = 14, style}) => {
  const f = useCurrentFrame();
  return (
    <div
      style={{
        fontFamily: MONO,
        fontSize: size,
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        color,
        opacity: p(f, start, 14) * 0.85,
        whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {children}
    </div>
  );
};

export const TopBar: React.FC<{
  left: string;
  mid?: string;
  right: string;
  color?: string;
  start?: number;
}> = ({left, mid, right, color = C.black, start = 0}) => (
  <div
    style={{
      position: 'absolute',
      top: 56,
      left: 48,
      right: 48,
      display: 'flex',
      justifyContent: 'space-between',
    }}
  >
    <Label color={color} start={start}>{left}</Label>
    {mid ? <Label color={color} start={start + 4}>{mid}</Label> : <span />}
    <Label color={color} start={start + 8}>{right}</Label>
  </div>
);

export const Barcode: React.FC<{w?: number; h?: number; color?: string; seed?: string}> = ({
  w = 140,
  h = 34,
  color = C.black,
  seed = 'bc',
}) => {
  const n = Math.floor(w / 3);
  return (
    <div style={{display: 'flex', gap: 1, height: h, width: w, overflow: 'hidden'}}>
      {Array.from({length: n}, (_, i) => (
        <div key={i} style={{width: 1 + Math.floor(random(seed + i) * 3), background: color, flex: 'none'}} />
      ))}
    </div>
  );
};

export const Ring: React.FC<{
  cx: number;
  cy: number;
  size: number;
  color?: string;
  opacity?: number;
  dashed?: boolean;
  rot?: number;
  w?: number;
  scale?: number;
}> = ({cx, cy, size, color = C.black, opacity = 0.25, dashed = false, rot = 0, w = 1, scale = 1}) => (
  <div
    style={{
      position: 'absolute',
      left: cx - size / 2,
      top: cy - size / 2,
      width: size,
      height: size,
      borderRadius: '50%',
      border: `${w}px ${dashed ? 'dashed' : 'solid'} ${color}`,
      opacity,
      transform: `rotate(${rot}deg) scale(${scale})`,
    }}
  />
);

export const Checker: React.FC<{size?: number; color?: string}> = ({size = 26, color = C.black}) => (
  <div
    style={{
      width: size,
      height: size,
      backgroundImage: `conic-gradient(${color} 25%, transparent 0 50%, ${color} 0 75%, transparent 0)`,
      backgroundSize: `${size / 4}px ${size / 4}px`,
      border: `1px solid ${color}`,
    }}
  />
);

/** Blur-to-focus text, word by word (or char by char). */
export const BlurText: React.FC<{
  text: string;
  start?: number;
  size: number;
  color?: string;
  weight?: number;
  stagger?: number;
  dur?: number;
  ls?: string;
  lh?: number;
  align?: 'left' | 'center' | 'right';
  by?: 'word' | 'char';
  style?: React.CSSProperties;
}> = ({text, start = 0, size, color = C.black, weight = 500, stagger = 4, dur = 22, ls = '-0.02em', lh = 1.15, align = 'left', by = 'word', style}) => {
  const f = useCurrentFrame();
  const parts = by === 'char' ? text.split('') : text.split(' ');
  return (
    <div style={{fontFamily: SANS, fontSize: size, fontWeight: weight, color, letterSpacing: ls, lineHeight: lh, textAlign: align, ...style}}>
      {parts.map((w, i) => {
        const t = p(f, start + i * stagger, dur);
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              opacity: t,
              filter: `blur(${(1 - t) * 18}px)`,
              transform: `translateY(${(1 - t) * 36}px)`,
              marginRight: by === 'word' ? '0.24em' : 0,
              whiteSpace: 'pre',
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** Oversized headline that rises out of a mask. */
export const MaskLine: React.FC<{
  text: React.ReactNode;
  start?: number;
  size: number;
  color?: string;
  weight?: number;
  dur?: number;
  ls?: string;
  align?: 'left' | 'center' | 'right';
  style?: React.CSSProperties;
}> = ({text, start = 0, size, color = C.black, weight = 900, dur = 24, ls = '-0.055em', align = 'left', style}) => {
  const f = useCurrentFrame();
  const t = p(f, start, dur);
  return (
    <div style={{overflow: 'hidden', lineHeight: 0.92, paddingTop: size * 0.06, paddingBottom: size * 0.06, textAlign: align}}>
      <div
        style={{
          fontFamily: SANS,
          fontSize: size,
          fontWeight: weight,
          letterSpacing: ls,
          color,
          transform: `translateY(${(1 - t) * 110}%)`,
          filter: `blur(${(1 - t) * 10}px)`,
          whiteSpace: 'nowrap',
          ...style,
        }}
      >
        {text}
      </div>
    </div>
  );
};

/** A timed block inside a scene with a soft exit. */
const BeatInner: React.FC<{dur: number; exit: number; children: React.ReactNode}> = ({dur, exit, children}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [dur - exit, dur], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const y = interpolate(f, [dur - exit, dur], [0, -30], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: INOUT});
  return <AbsoluteFill style={{opacity: o, transform: `translateY(${y}px)`}}>{children}</AbsoluteFill>;
};

export const Beat: React.FC<{from: number; dur: number; exit?: number; children: React.ReactNode}> = ({from, dur, exit = 8, children}) => (
  <Sequence from={from} durationInFrames={dur}>
    <BeatInner dur={dur} exit={exit}>{children}</BeatInner>
  </Sequence>
);

/** Colour panel that sweeps up across a scene boundary. `at` is the global cut frame. */
export const Wipe: React.FC<{at: number; color: string; dur?: number; label?: string}> = ({at, color, dur = 9, label}) => {
  const f = useCurrentFrame();
  if (f < at - dur || f > at + dur) return null;
  const y =
    f < at
      ? interpolate(f, [at - dur, at], [100, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: INOUT})
      : interpolate(f, [at, at + dur], [0, -100], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: INOUT});
  return (
    <AbsoluteFill style={{background: color, transform: `translateY(${y}%)`}}>
      {label ? (
        <div style={{position: 'absolute', left: 48, bottom: 64, fontFamily: MONO, fontSize: 14, letterSpacing: '0.12em', color: C.off, opacity: 0.8}}>
          {label}
        </div>
      ) : null}
    </AbsoluteFill>
  );
};

const NOISE = `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.5  0 0 0 0 0.5  0 0 0 0 0.5  0 0 0 1.2 -0.2'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")`;

/** Subtle film grain, re-jittered every other frame. */
export const Grain: React.FC = () => {
  const f = useCurrentFrame();
  const k = Math.floor(f / 2);
  return (
    <AbsoluteFill
      style={{
        pointerEvents: 'none',
        backgroundImage: NOISE,
        backgroundPosition: `${(k * 47) % 220}px ${(k * 83) % 220}px`,
        opacity: 0.1,
        mixBlendMode: 'overlay',
      }}
    />
  );
};
