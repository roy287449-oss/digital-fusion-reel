import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {C, SCENE_FRAMES} from './theme';
import {Grain, Wipe} from './ui';
import {Scene1} from './scenes/Scene1Intro';
import {Scene2} from './scenes/Scene2Object';
import {Scene3} from './scenes/Scene3Problem';
import {Scene4} from './scenes/Scene4Digital';
import {Scene5} from './scenes/Scene5Services';
import {Scene6} from './scenes/Scene6CTA';
import {Scene7} from './scenes/Scene7Outro';

const SCENES: {name: string; Comp: React.FC}[] = [
  {name: '1 Intro', Comp: Scene1},
  {name: '2 Object', Comp: Scene2},
  {name: '3 Problem', Comp: Scene3},
  {name: '4 Digital presence', Comp: Scene4},
  {name: '5 Services', Comp: Scene5},
  {name: '6 CTA', Comp: Scene6},
  {name: '7 Outro', Comp: Scene7},
];

// Colour of the wipe that covers each cut (index = cut between scene i and i+1)
const WIPES = [C.red, C.red, C.red, C.black, C.red, C.black];

export const MainVideo: React.FC = () => {
  const starts: number[] = [];
  let acc = 0;
  SCENE_FRAMES.forEach((d) => {
    starts.push(acc);
    acc += d;
  });

  return (
    <AbsoluteFill style={{background: C.black}}>
      {SCENES.map(({name, Comp}, i) => (
        <Sequence key={name} name={name} from={starts[i]} durationInFrames={SCENE_FRAMES[i]}>
          <Comp />
        </Sequence>
      ))}
      {WIPES.map((color, i) => (
        <Wipe key={i} at={starts[i + 1]} color={color} label={`DF — 0${i + 2}`} />
      ))}
      <Grain />
    </AbsoluteFill>
  );
};
