import React from 'react';
import {C, MONO, SANS} from './theme';
import {clamp01} from './anim';

/** CSS-3D cube. Faces are red / black / charcoal like the reference palette. */
export const Cube: React.FC<{s?: number; rx: number; ry: number}> = ({s = 230, rx, ry}) => {
  const h = s / 2;
  const face = (k: string, t: string, bg: string) => (
    <div
      key={k}
      style={{
        position: 'absolute',
        inset: 0,
        transform: t,
        background: bg,
        backfaceVisibility: 'hidden',
        boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.08)',
      }}
    />
  );
  return (
    <div style={{width: s, height: s, position: 'relative', transformStyle: 'preserve-3d', transform: `rotateX(${rx}deg) rotateY(${ry}deg)`}}>
      {face('f', `translateZ(${h}px)`, `linear-gradient(180deg, ${C.red} 0 52%, #fff 52% 55%, ${C.black} 55% 100%)`)}
      {face('b', `rotateY(180deg) translateZ(${h}px)`, C.black)}
      {face('r', `rotateY(90deg) translateZ(${h}px)`, 'repeating-linear-gradient(180deg, #2c2c2c 0 10px, #1b1b1b 10px 12px)')}
      {face('l', `rotateY(-90deg) translateZ(${h}px)`, '#9c0500')}
      {face('t', `rotateX(90deg) translateZ(${h}px)`, '#ff2f23')}
      {face('o', `rotateX(-90deg) translateZ(${h}px)`, C.black)}
    </div>
  );
};

export const Sphere: React.FC<{size: number; red?: boolean; style?: React.CSSProperties}> = ({size, red = false, style}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: '50%',
      background: red
        ? 'radial-gradient(circle at 32% 28%, #ff9a90 0%, #E10600 32%, #6d0200 78%, #1a0000 100%)'
        : 'radial-gradient(circle at 32% 28%, #ffffff 0%, #cfcfcf 18%, #6b6b6b 55%, #0d0d0d 100%)',
      boxShadow: '0 30px 60px rgba(0,0,0,0.35)',
      ...style,
    }}
  />
);

/** Glossy rounded app tile. */
export const Tile: React.FC<{size: number; children?: React.ReactNode; red?: boolean; style?: React.CSSProperties}> = ({size, children, red, style}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: size * 0.26,
      background: red
        ? 'linear-gradient(150deg, #ff5a4d 0%, #E10600 45%, #7a0300 100%)'
        : 'linear-gradient(150deg, #ffffff 0%, #d6d6d6 45%, #8d8d8d 100%)',
      boxShadow: '0 24px 40px rgba(0,0,0,0.35), inset 0 2px 0 rgba(255,255,255,0.7)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: SANS,
      fontWeight: 900,
      fontSize: size * 0.46,
      color: red ? '#fff' : C.black,
      ...style,
    }}
  >
    {children}
  </div>
);

/** Phone mockup, fixed 260×536. Scale it from outside with `transform`/`scale`. */
export const Phone: React.FC<{children?: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      width: 260,
      height: 536,
      borderRadius: 46,
      background: '#0b0b0b',
      padding: 9,
      boxSizing: 'border-box',
      boxShadow: '0 40px 70px rgba(0,0,0,0.35), inset 0 0 0 2px #2b2b2b',
      position: 'relative',
      ...style,
    }}
  >
    <div style={{width: '100%', height: '100%', borderRadius: 38, background: C.off, overflow: 'hidden', position: 'relative'}}>{children}</div>
    <div style={{position: 'absolute', top: 18, left: '50%', marginLeft: -38, width: 76, height: 20, borderRadius: 12, background: '#000'}} />
  </div>
);

/** Illustrative dashboard UI for the phone. No real numbers. `t` = 0→1 build-in. */
export const AppScreen: React.FC<{t: number}> = ({t}) => {
  const s = (i: number) => clamp01(t * 6 - i * 0.7);
  const bars = [0.35, 0.55, 0.4, 0.75, 0.6, 0.95];
  return (
    <div style={{padding: '52px 16px 16px', fontFamily: SANS, color: C.black, height: '100%', boxSizing: 'border-box'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 10, opacity: s(0)}}>
        <div style={{width: 34, height: 34, borderRadius: '50%', background: C.red}} />
        <div>
          <div style={{fontWeight: 700, fontSize: 14}}>Your Brand</div>
          <div style={{fontFamily: MONO, fontSize: 9, opacity: 0.5}}>DASHBOARD</div>
        </div>
      </div>
      <div style={{display: 'flex', gap: 8, marginTop: 16}}>
        {['Orders', 'Visitors'].map((l, i) => (
          <div
            key={l}
            style={{
              flex: 1,
              height: 96,
              background: i ? '#fff' : C.black,
              color: i ? C.black : '#fff',
              borderRadius: 14,
              padding: 12,
              boxSizing: 'border-box',
              opacity: s(1 + i),
              transform: `translateY(${(1 - s(1 + i)) * 20}px)`,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
            }}
          >
            <div style={{fontFamily: MONO, fontSize: 9, opacity: 0.6}}>{l.toUpperCase()}</div>
            <div style={{display: 'flex', alignItems: 'flex-end', gap: 4, height: 44}}>
              {bars.map((b, k) => (
                <div key={k} style={{flex: 1, height: `${b * 100 * s(3)}%`, background: k === 5 ? C.red : i ? C.black : '#fff', opacity: k === 5 ? 1 : 0.5, borderRadius: 2}} />
              ))}
            </div>
          </div>
        ))}
      </div>
      {[0, 1, 2, 3].map((i) => (
        <div
          key={i}
          style={{
            marginTop: 10,
            height: 46,
            borderRadius: 12,
            background: '#fff',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            padding: '0 12px',
            opacity: s(3 + i),
            transform: `translateX(${(1 - s(3 + i)) * 40}px)`,
          }}
        >
          <div style={{width: 10, height: 10, borderRadius: '50%', background: i === 0 ? C.red : C.black, opacity: i === 0 ? 1 : 0.2}} />
          <div style={{flex: 1}}>
            <div style={{height: 7, width: `${70 - i * 10}%`, background: C.black, opacity: 0.8, borderRadius: 4}} />
            <div style={{height: 5, width: '40%', background: C.black, opacity: 0.2, borderRadius: 4, marginTop: 6}} />
          </div>
        </div>
      ))}
    </div>
  );
};

/** Browser + website mockup, fixed 560×400. `t` = 0→1 build-in. */
export const Website: React.FC<{t: number}> = ({t}) => {
  const s = (i: number) => clamp01(t * 8 - i * 0.6);
  return (
    <div
      style={{
        width: 560,
        height: 400,
        borderRadius: 16,
        background: C.off,
        boxShadow: '0 40px 80px rgba(0,0,0,0.35), 0 0 0 1px rgba(0,0,0,0.12)',
        overflow: 'hidden',
        fontFamily: SANS,
        color: C.black,
        position: 'relative',
      }}
    >
      <div style={{height: 36, background: '#dcd8d0', display: 'flex', alignItems: 'center', gap: 6, padding: '0 14px'}}>
        {['#ff5f57', '#febc2e', '#28c840'].map((c) => (
          <div key={c} style={{width: 10, height: 10, borderRadius: '50%', background: c}} />
        ))}
        <div style={{marginLeft: 14, flex: 1, height: 20, borderRadius: 10, background: '#f3f1ec', fontFamily: MONO, fontSize: 10, display: 'flex', alignItems: 'center', paddingLeft: 12, opacity: 0.8}}>
          yourbrand.com
        </div>
      </div>
      <div style={{display: 'flex', justifyContent: 'space-between', padding: '14px 22px', opacity: s(0)}}>
        <div style={{fontWeight: 900, fontSize: 15, letterSpacing: '-0.04em'}}>BRAND<span style={{color: C.red}}>.</span></div>
        <div style={{display: 'flex', gap: 16, fontFamily: MONO, fontSize: 9, opacity: 0.6}}>
          <span>SHOP</span><span>STORY</span><span>CONTACT</span>
        </div>
      </div>
      <div
        style={{
          margin: '0 22px',
          height: 142,
          borderRadius: 12,
          background: C.black,
          position: 'relative',
          overflow: 'hidden',
          opacity: s(1),
          transform: `translateY(${(1 - s(1)) * 24}px)`,
        }}
      >
        <div style={{position: 'absolute', right: -30, top: -30, width: 190, height: 190, borderRadius: '50%', background: C.red}} />
        <div style={{position: 'absolute', left: 22, top: 30, color: '#fff', fontWeight: 900, fontSize: 30, letterSpacing: '-0.05em', lineHeight: 0.95}}>
          Your brand.<br />Your home.
        </div>
        <div style={{position: 'absolute', left: 22, bottom: 18, width: 84, height: 24, borderRadius: 12, background: '#fff'}} />
      </div>
      <div style={{display: 'flex', gap: 10, margin: '14px 22px 0'}}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              flex: 1,
              height: 96,
              borderRadius: 10,
              background: i === 1 ? C.red : '#fff',
              opacity: s(2 + i),
              transform: `translateY(${(1 - s(2 + i)) * 24}px)`,
              padding: 10,
              boxSizing: 'border-box',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'flex-end',
              gap: 5,
            }}
          >
            <div style={{height: 6, width: '70%', background: i === 1 ? '#fff' : C.black, opacity: 0.8, borderRadius: 3}} />
            <div style={{height: 5, width: '40%', background: i === 1 ? '#fff' : C.black, opacity: 0.3, borderRadius: 3}} />
          </div>
        ))}
      </div>
    </div>
  );
};

/** Floating UI chip. */
export const Chip: React.FC<{children: React.ReactNode; dark?: boolean; style?: React.CSSProperties}> = ({children, dark = false, style}) => (
  <div
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      padding: '12px 18px',
      borderRadius: 12,
      background: dark ? C.black : '#fff',
      color: dark ? '#fff' : C.black,
      border: dark ? `1px solid ${C.red}` : '1px solid rgba(0,0,0,0.12)',
      fontFamily: SANS,
      fontWeight: 700,
      fontSize: 22,
      boxShadow: '0 14px 30px rgba(0,0,0,0.18)',
      whiteSpace: 'nowrap',
      ...style,
    }}
  >
    <span style={{width: 10, height: 10, borderRadius: '50%', background: C.red}} />
    {children}
  </div>
);
