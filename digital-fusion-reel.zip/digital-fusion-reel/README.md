# Digital Fusion Reel (Remotion)

720×1280 · 30 fps · 1230 frames (41 s) · composition id `DigitalFusionReel`

## Edit your details
Open `src/config.ts` and replace the phone, email, website. To use your logo,
put it in `public/` and set `logoSrc: 'logo.png'`.

## Run / render
    npm install
    npm run dev       # live preview (Remotion Studio, port 3000)
    npm run build     # renders out/digital-fusion-reel.mp4
    npm run still     # renders one frame to out/frame.png

Fonts (Inter, JetBrains Mono) are fetched from Google Fonts when the video loads/renders,
so the machine needs internet. Everything else is local, original code. No audio included.
